import org.codehaus.groovy.grails.commons.GrailsClassUtils as GCU

grailsHome = Ant.project.properties."environment.GRAILS_HOME"

includeTargets << grailsScript ( "Init" )
includeTargets << grailsScript ( "InstallPlugin" )

target('default': "The description of the script goes here!") {
    args = "/Users/skrenek/Workspaces/ZeddWare/FilterPanePlugin/grails-filterpane-0.6.zip"
    installPlugin()
}