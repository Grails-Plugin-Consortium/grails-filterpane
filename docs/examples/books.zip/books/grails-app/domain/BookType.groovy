/**
 *
 * @author steve.krenek
 */
enum BookType {
	Fiction, NonFiction, Reference
}

