class Book {
	Author author
	String title
	Date releaseDate
	Boolean inStock
	BigDecimal price
	Date lastUpdated
	
	static constraints = {
		title(blank:false)
		author()
		releaseDate()
		price()
		inStock()
		lastUpdated(nullable:true)
	}
	
	static mapping = {
		author lazy:false
	}
	
	String toString() {
		return title
	}
}
