class Book {
	Author author
	String title
	Date releaseDate
	Boolean inStock
	BigDecimal price
	Date lastUpdated
    String readPriority
    BigDecimal cost
	
	static constraints = {
		title(blank:false)
		author()
		releaseDate()
		price()
		inStock()
		lastUpdated(nullable:true)
        readPriority(inList:['Low','Normal','High'])
        cost(min:0.00)
	}
	
	static mapping = {
		author lazy:false
	}
	
	String toString() {
		return title
	}
}
