class BookTests extends GroovyTestCase {

    void testSomething() {

    }
}
