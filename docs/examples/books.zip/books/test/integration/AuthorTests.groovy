class AuthorTests extends GroovyTestCase {

    void testSomething() {

    }
}
